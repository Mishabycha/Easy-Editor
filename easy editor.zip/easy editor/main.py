import os
from PyQt5.QtWidgets import (
    QApplication, QWidget,
    QFileDialog,
    QLabel, QPushButton, QListWidget,
    QHBoxLayout, QVBoxLayout
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PIL import Image, ImageFilter

#Створення стилю
style = '''
QWidget{
    background-color: rgb(0, 0, 0);
}
QLabel{
    color: rgb(128, 128, 128);
    font-weight: bold;
}
QPushButton{
    color: rgb(0, 0, 0);
    background-color: rgb(128, 128, 128);
    font-weight: bold;
    height: 20px;
    border: 2px solid rgb(100, 100, 100)
}
QListWidget{
    color: rgb(0, 0, 0);
    background-color: rgb(128, 128, 128);
    font-weight: bold;
    border-radius: 5px;
    border: 2px solid rgb(100, 100, 100)
}

'''

app = QApplication([])

app.setStyleSheet(style)

win = QWidget()
win.resize(700, 500)
win.setWindowTitle("PhotoShop 1488")

'''Інтерфейс програми'''
btn_dir = QPushButton("Знайти фото")
lw_files = QListWidget()
lbl_image = QLabel("Зображення")

btn_left = QPushButton("Вліво")
btn_right = QPushButton("Вправо")
btn_mirror = QPushButton("Дзеркало")
btn_sharp = QPushButton("Розмиття")
btn_bw = QPushButton("Ч/Б")
btn_clear = QPushButton("Очистити")
btn_detail = QPushButton("Деталізація")
btn_2 = QPushButton("Показ ліній")

row = QHBoxLayout()

col1 = QVBoxLayout()
col2 = QVBoxLayout()

col1.addWidget(btn_dir)
col1.addWidget(lw_files)

col2.addWidget(lbl_image)

row.addWidget(btn_bw)
row.addWidget(btn_left)
row.addWidget(btn_right)
row.addWidget(btn_sharp)
row.addWidget(btn_mirror)
row.addWidget(btn_clear)
row.addWidget(btn_detail)
row.addWidget(btn_2)

col2.addLayout(row)

main_line = QHBoxLayout()
main_line.addLayout(col1, 20)
main_line.addLayout(col2, 80)

win.setLayout(main_line)
win.show()

'''Функціонал'''
workdir = ""

def filter(files, extentions):
    result = []
    for filename in files:
        for ext in extentions:
           if filename.endswith(ext): # 'photo.png' -> '.png' -> True
                result.append(filename)

    return result

def show_filenames_list():
    """Функція для відкривання папки в программі"""
    global workdir
    extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp']
    try:
        workdir = QFileDialog.getExistingDirectory()
        filenames = filter(os.listdir(workdir), extensions)
    except:
        workdir = ""
        filenames = []

    lw_files.clear()
    lw_files.addItems(filenames)

class ImageProcesor():
    def __init__(self):
        self.image = None
        self.filename = None
        self.dir = None
        self.save_dir = "Modified/"

    def load_image(self, dir, filename):
        """Функція для завантаження зображення"""
        self.dir = dir
        self.filename = filename
        imagepath = os.path.join(dir, filename)
        self.image = Image.open(imagepath)
    
    def showimage(self, path):
        """Функція для показу зображення"""
        lbl_image.hide()
        preview = QPixmap(path)
        w, h = lbl_image.width(), lbl_image.height()
        preview = preview.scaled(w, h, Qt.KeepAspectRatio)
        lbl_image.setPixmap(preview)
        lbl_image.show()

    def save_image(self):
        """Функція для збереження зображення"""
        path = os.path.join(workdir, self.save_dir)
        if not(os.path.exists(path) or os.path.isdir(path)):
            os.mkdir(path)
        fullpath = os.path.join(path, self.filename)
        self.image.save(fullpath)

    def clear_image(self):
        """Функція для очищення зображення"""
        self.load_image(self.dir, self.filename)
        path = os.path.join(workdir, self.filename)
        self.showimage(path)

    def blur(self):
        """Функція для розмиття зображення"""
        self.image = self.image.filter(ImageFilter.BLUR)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def do_left(self):
        """Функція для повороту зображення вліво"""
        self.image = self.image.transpose(Image.ROTATE_90)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def do_right(self):
        """Функція для повороту зображення вправо"""
        self.image = self.image.transpose(Image.ROTATE_270)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def do_bw(self): 
        """Функція, яка робить картинку чорнобілою"""
        self.image = self.image.convert("L")
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def mirror(self):
        """Функція, яка робить картинку дзеркальною"""
        self.image = self.image.transpose(Image.FLIP_LEFT_RIGHT)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def detail(self):
        """Функція, яка пікселізує зображення"""
        self.image = self.image.filter(ImageFilter.DETAIL)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)

    def fund_edges(self):
        """Функція, яка показує межі зображення"""
        self.image = self.image.filter(ImageFilter.SMOOTH)
        self.image = self.image.filter(ImageFilter.FIND_EDGES)
        self.save_image()
        fullpath = os.path.join(workdir, self.save_dir, self.filename)
        self.showimage(fullpath)


workimage = ImageProcesor()

def show_choosen_image():
    """Функція для відображення назв файлів"""
    if lw_files.currentRow() >= 0:
        filename = lw_files.currentItem().text()
        workimage.load_image(workdir, filename)
        imagepath = os.path.join(workdir, filename)
        workimage.showimage(imagepath)


btn_dir.clicked.connect(show_filenames_list)
lw_files.currentRowChanged.connect(show_choosen_image)
btn_bw.clicked.connect(workimage.do_bw)
btn_clear.clicked.connect(workimage.clear_image)
btn_left.clicked.connect(workimage.do_left)
btn_right.clicked.connect(workimage.do_right)
btn_mirror.clicked.connect(workimage.mirror)
btn_sharp.clicked.connect(workimage.blur)
btn_detail.clicked.connect(workimage.detail)
btn_2.clicked.connect(workimage.fund_edges)








app.exec_()



